import React from 'react';

export default function DetailSection5Component(props) {
    return (
        <section id='detailSection5'>
            
        </section>
    );
}

