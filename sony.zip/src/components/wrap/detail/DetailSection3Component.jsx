import React from 'react';

export default function DetailSection3Component(props) {
    return (
        <section id='detailSection3'>
            
        </section>
    );
}

