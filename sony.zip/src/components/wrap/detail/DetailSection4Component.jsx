import React from 'react';

export default function DetailSection4Component(props) {
    return (
        <section id='detailSection4'>
            
        </section>
    );
}

