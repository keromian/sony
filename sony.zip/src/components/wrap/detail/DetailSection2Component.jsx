import React from 'react';

export default function DetailSection2Component(props) {
    return (
        <section id='detailSection2'>
            
        </section>
    );
}

